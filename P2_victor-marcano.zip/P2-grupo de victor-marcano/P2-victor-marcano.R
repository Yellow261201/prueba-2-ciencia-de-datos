library( readxl)
library(tidyverse)
library(ggrepel)
library(dslabs)
library(stringr)
library(zoo)
library(lubridate)
library(rvest)
library(tidyr)
library(gridExtra)

#1. Limpieza de la base de datos------------------------------------------------
#1.1 Pivote de la data para su lim´pieza----------------------------------------

datos_aire <- read_excel("Air_Quality.xlsx")

variables <- c( "Ozone (O3)",  
                "Nitrogen Dioxide (NO2)",
                "O3-Attributable Cardiac and Respiratory Deaths")
                
Filtro1 <- c( "Annual Average 2009", "Annual Average 2010", "Annual Average 2011",
              "Annual Average 2012", "Annual Average 2013", "Annual Average 2014", 
              "Annual Average 2015", "Annual Average 2016", "Annual Average 2017",
              "Annual Average 2018", "Annual Average 2019", "Annual Average 2021")


datos_aire_new <- datos_aire %>% 
  
  rename( "Period" = "Time Period",
          
          "GeoType" = "Geo Type Name") %>%
  
  filter(!Period %in% Filtro1) %>%
  
  filter(GeoType != "UHF34") %>%
  
  select(-(1:2), -(4:7), -9, -12) %>%
  
  filter(Name %in% variables) %>%
  
  distinct()


  datos_aire_new$Start_Date <- ydm(datos_aire_new$Start_Date)
  
  datos_aire_new <- arrange(datos_aire_new, Start_Date) %>% 
    
    na.omit()

  calidad_aire <- datos_aire_new %>%
   
   pivot_wider( names_from = "Name",
               
               values_from = "Data Value") %>%
    
    rename( "dioxido_nitrogeno" = "Nitrogen Dioxide (NO2)",
            
            "ozono" = "Ozone (O3)",
            
            "fecha" = "Start_Date",
            
            "geo_lugar" ="Geo Place Name",
            
            "problemas_cardiacos" ="O3-Attributable Cardiac and Respiratory Deaths")  %>%
    
    arrange(desc(fecha) ) %>%
    
    transform(dioxido_nitrogeno = as.numeric(dioxido_nitrogeno),
        
                ozono = as.numeric(ozono),
              
                problemas_cardiacos = as.numeric(problemas_cardiacos))
#1.2 Organización individual de las variables para concretar la base de datos---

#1.2.1 organizacion de la lista de variables a trabajar-------------------------
 
 
 lista_variables <- calidad_aire %>%
   
   replace_na(list(dioxido_nitrogeno = 0)) %>%
    
   replace_na(list(ozono =0)) 
    
 
 promedio_nitrogeno <- lista_variables %>%
   
   group_by(fecha,dioxido_nitrogeno) %>%
   
   summarise(dioxido_nitrogeno = mean(dioxido_nitrogeno, na.rm=TRUE)) %>%
   
   ungroup()
 
 
 promedio_ozono <- lista_variables  %>%
   
   group_by(fecha,ozono) %>%
   
   summarise(ozono = mean.default(ozono, na.rm=TRUE)) %>%
   
   ungroup()
 

lugar<- "Brooklyn"
#1.2.2 acomodo de los datos de forma anual--------------------------------------

datos_anuales <- lista_variables %>%
  
  separate(fecha, c("year" , "moth"), sep = "-" )%>%
  
  select(-ozono) %>%
  
  pivot_wider(names_from = moth, 
              
              values_from = dioxido_nitrogeno) 

#1.2.3 acomodo del dioxido de nitrogeno como variable---------------------------

datos_anuales$dioxido_nitrogeno_media <- rowMeans(datos_anuales[, c(4,5,6)],
                                                  
                                                  na.rm = TRUE)

dioxido_nitrogeno <- datos_anuales %>%
  
  select(-problemas_cardiacos, -06, -04, -05)

#1.2.4 acomodo del ozono como variable------------------------------------------

ozono <- lista_variables %>%
  
  separate(fecha, c("year" , "moth"), sep = "-" )%>%
  
  select(-dioxido_nitrogeno) %>%
  
  pivot_wider(names_from = moth, 
              
              values_from = ozono)

ozono$ozono_media <- rowMeans(ozono[, c(4,5,6)],
                                          
                                          na.rm = TRUE)

ozono <- ozono %>%
  
  select(-problemas_cardiacos, -06, -04, -05)

#1.2.5 Union de variables a trabajar con ozono y dioxido de nitrogeno-----------

calidad_aire <-  merge(dioxido_nitrogeno, ozono, all = TRUE) 


calidad_aire<- calidad_aire %>%

  
  rename(localizacion = geo_lugar,
         
         nitrogeno_media =dioxido_nitrogeno_media)
  
  
calidad_aire <- transform(calidad_aire, nitrogeno_media = as.double(nitrogeno_media), 
                     
         localizacion = as.character(localizacion), 
                     
          ozono_media = as.double(ozono_media))
  
  

#1.2.6 acomodo de los problemas cardidacos como variable------------------------

enfermedad <- lista_variables %>%
  
  separate(fecha, c("year" , "moth"), sep = "-" )%>%
  
  select(-ozono, -dioxido_nitrogeno) %>%
  
  pivot_wider(names_from = moth, 
              
              values_from = problemas_cardiacos)

problemas_cardiacos <- enfermedad %>%
  select(-3, -5) %>%
  na.omit() %>%
  rename(muertes_media = 3,
         localizacion = geo_lugar)

remove(datos_aire_new,
       enfermedad,
       lista_variables,
       promedio_nitrogeno,
       promedio_ozono,
       datos_anuales,
       dioxido_nitrogeno,
       ozono)


#1.3 GRAFICAs-------------------------------------------------------------------

#1.3.1 Grafico 1, Dioxido de nitrogeno a lo largo de los años-------------------


new_york <-c("East New York and Starrett City (CD5)")

grafico <- calidad_aire %>% filter(localizacion == new_york)

 grafico %>%   
   
   ggplot(aes(year,nitrogeno_media)) + 
                          
    geom_point(aes(year, nitrogeno_media), color = "deepskyblue4", size = 3) +
  
  xlab("year") +
  
  ylab("nitrogeno_media") +
   
   labs(title="Linea de tiempo del Dioxido de nitrogeno", x="Años", y = "Dioxido de nitrogeno") +
   
   theme_classic()

 


#1.3.2 grafico 2, Ozono a lo largo de los años---------------------------------- 

grafico  %>% 
   
   filter(localizacion == new_york) %>%
  
  ggplot(aes(year , ozono_media)) +
  
  geom_point(aes( year, ozono_media), color = "deepskyblue4", size = 3) +
  
  scale_y_continuous(limits = c(10,20)) +
   
   labs(title="Linea de tiempo del Ozono", x="Años", y = "Ozono") +
  
  xlab("year") +
  
  ylab("ozono_media")  +
   
   theme_classic()
#1.3.3 Grafico 3, problemas cardiacos de ciertos estados para cada año----------

years<- c(2005, 2009, 2012, 2015)
years<- as.numeric(years)



distrito<-c("East New York", 
            "Bronx",
            "Brooklyn",
            "Manhattan")


problemas_cardiacos %>% 
  
  filter(year %in% years & localizacion %in% distrito ) %>% 
  
  ggplot(aes(year, muertes_media, group = localizacion)) + 
  
  geom_line(aes(color= localizacion)) +
  
  labs(title="Linea de tiempo de las muertes por los problemas cardiacos",x="años", y = "afecciones y  problemas csrdiacos ") +
  
  geom_point() +
  
  theme_classic()


write.table(calidad_aire , file ="calidad_aire.csv" , sep =";" , row.names = F)

write.table(problemas_cardiacos , file ="problemas_cardiacos.csv" , sep =";" , row.names = F)

write.table(grafico, file ="grafico.csv" , sep=";" , row.names = F )

